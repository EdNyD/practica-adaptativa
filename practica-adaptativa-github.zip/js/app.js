const $ = id => document.getElementById(id);

const estadoApi = $("estadoApi");
const inicio = $("inicio");
const actividad = $("actividad");
const errorGeneral = $("errorGeneral");
const textoError = $("textoError");

const carnet = $("carnet");
const btnIniciar = $("btnIniciar");
const mensajeInicio = $("mensajeInicio");

const nombreActividad = $("nombreActividad");
const descripcionActividad = $("descripcionActividad");
const totalItems = $("totalItems");
const actividadId = $("actividadId");
const carnetVisible = $("carnetVisible");
const listaItems = $("listaItems");


function validarCarnet(valor) {
  return /^[A-Z]{2}[0-9]{5}$/.test(valor);
}


async function comprobarConexion() {

  try {

    const respuesta = await probarAPI();

    estadoApi.textContent =
      `API conectada · v${respuesta.version || "1"}`;

    estadoApi.className =
      "estado estado-ok";

  } catch (error) {

    estadoApi.textContent =
      "API no disponible";

    estadoApi.className =
      "estado estado-error";

    mostrarErrorGeneral(
      "No se pudo conectar con Apps Script. " +
      error.message
    );
  }
}


async function iniciarPractica() {

  const valorCarnet =
    carnet.value.trim().toUpperCase();

  carnet.value = valorCarnet;

  mensajeInicio.innerHTML = "";


  if (!validarCarnet(valorCarnet)) {

    mensajeInicio.innerHTML =
      `<div class="mensaje-error">
        El Número de Carnet debe contener
        dos letras iniciales y cinco dígitos.
        Ejemplo: AB12345.
      </div>`;

    return;
  }


  btnIniciar.disabled = true;
  btnIniciar.textContent = "Cargando…";


  try {

    const datos =
      await cargarActividadCompleta(
        CONFIG.ACTIVIDAD_ID
      );

    mostrarActividad(
      datos,
      valorCarnet
    );

  } catch (error) {

    mostrarErrorGeneral(
      "La actividad no pudo cargarse. " +
      error.message
    );

  } finally {

    btnIniciar.disabled = false;
    btnIniciar.textContent = "Cargar práctica";

  }
}


function mostrarActividad(datos, valorCarnet) {

  const act = datos.actividad;

  nombreActividad.textContent =
    act.Nombre || "Actividad";

  descripcionActividad.textContent =
    act.Descripcion || "";

  totalItems.textContent =
    datos.totalItems || 0;

  actividadId.textContent =
    act.Actividad_ID || CONFIG.ACTIVIDAD_ID;

  carnetVisible.textContent =
    valorCarnet;


  listaItems.innerHTML = "";


  (datos.items || []).forEach(
    (item, indice) => {

      const bloque =
        document.createElement("div");

      bloque.className = "item";

      bloque.innerHTML = `
        <strong>
          ${indice + 1}. ${item.Competencia}
        </strong>

        <div class="item-meta">
          ${item.Item_ID}
          · Nivel ${item.Nivel}
          · ${item.Tipo}
          · ${item.parametros?.length || 0} parámetros
          · ${item.opciones?.length || 0} opciones
        </div>
      `;

      listaItems.appendChild(bloque);

    }
  );


  inicio.classList.add("oculto");
  errorGeneral.classList.add("oculto");
  actividad.classList.remove("oculto");

  window.scrollTo({
    top: 0,
    behavior: "smooth"
  });
}


function mostrarErrorGeneral(mensaje) {

  textoError.textContent = mensaje;

  errorGeneral.classList.remove("oculto");
}


btnIniciar.addEventListener(
  "click",
  iniciarPractica
);


carnet.addEventListener(
  "keydown",
  event => {

    if (event.key === "Enter") {
      iniciarPractica();
    }

  }
);


comprobarConexion();
