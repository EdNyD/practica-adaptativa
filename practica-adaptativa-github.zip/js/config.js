const CONFIG = {
  API_URL: "https://script.google.com/macros/s/AKfycbyLOiZE8MBrNJV_94kfnA7RVYyLAPgJwGQGRGD3D8IfdeetDKfbriReW7utuiDhc4ED/exec",
  ACTIVIDAD_ID: "DEMO-DER-01"
};
