async function apiGet(params = {}) {
  const url = new URL(CONFIG.API_URL);

  Object.entries(params).forEach(([clave, valor]) => {
    if (valor !== undefined && valor !== null && valor !== "") {
      url.searchParams.set(clave, valor);
    }
  });

  const respuesta = await fetch(url.toString(), {
    method: "GET"
  });

  if (!respuesta.ok) {
    throw new Error(
      `Error HTTP ${respuesta.status}`
    );
  }

  const datos = await respuesta.json();

  if (!datos.ok) {
    throw new Error(
      datos.error || "La API devolvió un error."
    );
  }

  return datos;
}


async function probarAPI() {
  return apiGet({
    accion: "ping"
  });
}


async function cargarActividadCompleta(actividadId) {
  return apiGet({
    accion: "actividadCompleta",
    actividad: actividadId
  });
}
